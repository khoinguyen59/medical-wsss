"""
Clinical Visualization & Results Packaging Module for SE374.R11 BCSS-WSSS Pipeline.

Provides:
1. IEEE / Springer 5-class histopathology color palette and mask colorizer.
2. Diversity-ranked patient patch selector across distinct TCGA patients.
3. 300-DPI Clinical Segmentation Comparison Figure (5 columns: H&E, Doctor GT,
   Baseline M1, Proposed SOTA M5, Clinical Overlay).
4. 300-DPI Normalized 5x5 Confusion Matrix Heatmap.
5. 300-DPI Multi-Method Ablation Study Bar Chart.
6. Timestamped ZIP archiver with optional Google Drive backup and Colab browser download.

All hyphens strictly use standard ASCII 0x2D ('-').
"""

from pathlib import Path
import shutil
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
import zipfile
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import torch
from torchvision import transforms

try:
    from .downloader import extract_patient_id
    from .evaluator import CLASS_CODES
except ImportError:
    from downloader import extract_patient_id
    from evaluator import CLASS_CODES


# IEEE / Springer standard 5-class histopathology RGB palette
DISCRETE_PALETTE: np.ndarray = np.array(
    [
        [228, 26, 28],    # 0: TUM (Red - Tumor)
        [77, 175, 74],    # 1: STR (Green - Stroma)
        [55, 126, 184],   # 2: LYM (Blue - Lymphocytic infiltrate)
        [255, 127, 0],    # 3: NEC (Orange - Necrosis)
        [153, 153, 153],  # 4: BACK (Gray - White glass / Outside ROI)
    ],
    dtype=np.uint8,
)


def colorize_mask(mask_2d: np.ndarray) -> np.ndarray:
    """Maps a 2D integer mask in {0..4} to an (H, W, 3) uint8 RGB image."""
    clamped = np.clip(mask_2d, 0, 4).astype(np.int64)
    return DISCRETE_PALETTE[clamped]


def select_diverse_clinical_samples(
    active_test_files: List[Path],
    test_mask_dir: Union[str, Path],
    sample_count: int = 4,
    patient_id_fn: Callable[[str], str] = extract_patient_id,
) -> List[Path]:
    """Selects up to sample_count patches from distinct patients with highest tissue class diversity."""
    mask_dir = Path(test_mask_dir)
    target_n = min(sample_count, len(active_test_files))
    if target_n <= 0:
        return []

    scored_candidates: List[Tuple[int, str, Path]] = []
    for p in active_test_files:
        m_p = mask_dir / p.name
        if m_p.exists():
            m_arr = np.array(Image.open(m_p), dtype=np.int64)
            unique_cls = len(np.unique(m_arr))
            scored_candidates.append((unique_cls, patient_id_fn(p.name), p))
        else:
            scored_candidates.append((1, patient_id_fn(p.name), p))

    scored_candidates.sort(key=lambda item: (-item[0], item[1]))
    sample_files: List[Path] = []
    seen_pids = set()
    for _, pid, p in scored_candidates:
        if pid not in seen_pids:
            sample_files.append(p)
            seen_pids.add(pid)
            if len(sample_files) >= target_n:
                break

    if len(sample_files) < target_n:
        for _, _, p in scored_candidates:
            if p not in sample_files:
                sample_files.append(p)
                if len(sample_files) >= target_n:
                    break

    return sample_files


def render_clinical_comparison_figure(
    active_test_files: List[Path],
    test_mask_dir: Union[str, Path],
    model: torch.nn.Module,
    wsss_engine: Any,
    best_method_key: str = "M5_Proposed_SOTA_Ensemble",
    model_stage1: Optional[torch.nn.Module] = None,
    device: Optional[Union[str, torch.device]] = None,
    output_dir: Optional[Union[str, Path]] = None,
    legacy_dir: Optional[Union[str, Path]] = None,
    sample_count: int = 4,
    show_plots: bool = True,
) -> Tuple[Optional[plt.Figure], Optional[Path]]:
    """Renders and saves the 300-DPI 5-column clinical comparison figure."""
    mask_dir = Path(test_mask_dir)
    sample_files = select_diverse_clinical_samples(
        active_test_files, mask_dir, sample_count=sample_count
    )
    if not sample_files:
        return None, None

    if device is None:
        dev = next(model.parameters()).device
    elif isinstance(device, str):
        dev = torch.device(device)
    else:
        dev = device

    transform = transforms.Compose([transforms.ToTensor()])
    n_rows = len(sample_files)
    fig_vis, axes = plt.subplots(n_rows, 5, figsize=(22.5, 4.4 * n_rows), dpi=300)
    if n_rows == 1:
        axes = np.expand_dims(axes, axis=0)

    for row_idx, img_p in enumerate(sample_files):
        raw_img = Image.open(img_p).convert("RGB")
        raw_np = np.array(raw_img)
        gt_p = mask_dir / img_p.name
        gt = (
            np.array(Image.open(gt_p), dtype=np.int64)
            if gt_p.exists()
            else np.full(raw_np.shape[:2], 4, dtype=np.int64)
        )

        t_tensor = transform(raw_img).unsqueeze(0).to(dev)
        vis_preds = wsss_engine.predict_all_methods(
            model, t_tensor, raw_rgb=raw_np, model_stage1=model_stage1
        )
        if best_method_key not in vis_preds and hasattr(wsss_engine, "predict_all_methods_v2"):
            vis_preds = wsss_engine.predict_all_methods_v2(
                model, t_tensor, raw_rgb=raw_np, model_stage1=model_stage1
            )
        best_pred_raw = vis_preds.get(
            best_method_key,
            vis_preds.get("M5_Proposed_SOTA_Ensemble", vis_preds["M1_Baseline_SingleScale"]),
        )
        pred_m1_vis = wsss_engine.apply_pure_glass_guard(
            vis_preds["M1_Baseline_SingleScale"], raw_np, background_class_idx=4
        )
        pred_best_vis = wsss_engine.apply_pure_glass_guard(
            best_pred_raw, raw_np, background_class_idx=4
        )

        outside_roi_mask = gt == 4
        pred_m1_display = pred_m1_vis.copy()
        pred_m1_display[outside_roi_mask] = 4
        pred_best_display = pred_best_vis.copy()
        pred_best_display[outside_roi_mask] = 4

        roi_pixels = (gt >= 0) & (gt < 4)
        acc_m1_sample = (
            float((pred_m1_vis[roi_pixels] == gt[roi_pixels]).mean() * 100.0)
            if np.any(roi_pixels)
            else 0.0
        )
        acc_best_sample = (
            float((pred_best_vis[roi_pixels] == gt[roi_pixels]).mean() * 100.0)
            if np.any(roi_pixels)
            else 0.0
        )

        gt_colored = colorize_mask(gt)
        m1_colored = colorize_mask(pred_m1_display)
        pred_colored = colorize_mask(pred_best_display)
        overlay = (0.60 * raw_np + 0.40 * pred_colored).astype(np.uint8)
        patient_id = extract_patient_id(img_p.name)
        best_short_tag = best_method_key.split("_")[0] if "_" in best_method_key else "M5"

        axes[row_idx, 0].imshow(raw_np)
        axes[row_idx, 0].set_title(
            f"Bệnh nhân: {patient_id}\n(Tiêu bản H&E gốc)", fontsize=11, fontweight="bold"
        )
        axes[row_idx, 0].axis("off")

        axes[row_idx, 1].imshow(gt_colored)
        axes[row_idx, 1].set_title(
            "Ground Truth Bác Sĩ\n(Vẽ tay trên kính hiển vi)", fontsize=11, fontweight="bold"
        )
        axes[row_idx, 1].axis("off")

        axes[row_idx, 2].imshow(m1_colored)
        axes[row_idx, 2].set_title(
            f"Baseline WSSS-Tissue (M1)\n(Khớp ROI: {acc_m1_sample:.1f}%)",
            fontsize=11,
            fontweight="bold",
        )
        axes[row_idx, 2].axis("off")

        axes[row_idx, 3].imshow(pred_colored)
        axes[row_idx, 3].set_title(
            f"Đề Xuất Cải Tiến ({best_short_tag} SOTA)\n(Khớp ROI: {acc_best_sample:.1f}%)",
            fontsize=11,
            fontweight="bold",
        )
        axes[row_idx, 3].axis("off")

        axes[row_idx, 4].imshow(overlay)
        axes[row_idx, 4].set_title(
            "Lớp Phủ Overlay Lâm Sàng\n(alpha = 0.40 trên H&E)", fontsize=11, fontweight="bold"
        )
        axes[row_idx, 4].axis("off")

    patches_legend = [
        plt.Rectangle((0, 0), 1, 1, color=DISCRETE_PALETTE[0] / 255.0, label="Khối U (TUM)"),
        plt.Rectangle((0, 0), 1, 1, color=DISCRETE_PALETTE[1] / 255.0, label="Mô Đệm (STR)"),
        plt.Rectangle((0, 0), 1, 1, color=DISCRETE_PALETTE[2] / 255.0, label="Lympho (LYM)"),
        plt.Rectangle((0, 0), 1, 1, color=DISCRETE_PALETTE[3] / 255.0, label="Hoại Tử (NEC)"),
        plt.Rectangle(
            (0, 0), 1, 1, color=DISCRETE_PALETTE[4] / 255.0, label="Kính Trắng / Ngoài ROI (BACK)"
        ),
    ]
    fig_vis.legend(
        handles=patches_legend,
        loc="lower center",
        ncol=5,
        fontsize=11,
        frameon=True,
        bbox_to_anchor=(0.5, -0.01),
    )
    plt.tight_layout()

    saved_path: Optional[Path] = None
    if output_dir is not None:
        out_p = Path(output_dir)
        out_p.mkdir(parents=True, exist_ok=True)
        saved_path = out_p / "clinical_segmentation_comparison.png"
        fig_vis.savefig(saved_path, dpi=300, bbox_inches="tight")
        if legacy_dir is not None:
            leg_p = Path(legacy_dir)
            leg_p.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved_path, leg_p / "clinical_segmentation_comparison.png")
        print(f"[OK] Đã lưu ảnh phân vùng lâm sàng 300 DPI: {saved_path.resolve()}")

    if show_plots:
        plt.show()
    else:
        plt.close(fig_vis)

    return fig_vis, saved_path


def render_confusion_matrix_heatmap(
    confusion_matrix: Union[List[List[int]], np.ndarray],
    class_codes: Optional[List[str]] = None,
    output_dir: Optional[Union[str, Path]] = None,
    legacy_dir: Optional[Union[str, Path]] = None,
    show_plots: bool = True,
) -> Tuple[plt.Figure, Optional[Path]]:
    """Renders and saves the 300-DPI normalized 5x5 confusion matrix heatmap."""
    codes = class_codes or list(CLASS_CODES)
    cm = np.array(confusion_matrix, dtype=np.int64)
    n_cls = cm.shape[0]

    fig_cm, ax_cm = plt.subplots(figsize=(7.5, 6.2), dpi=300)
    cm_norm = cm.astype(np.float64) / np.maximum(cm.sum(axis=1, keepdims=True), 1.0) * 100.0
    cax = ax_cm.imshow(cm_norm, cmap="Blues", interpolation="nearest")
    fig_cm.colorbar(cax, ax=ax_cm, label="Phần Trăm Chuẩn Hóa Theo Hàng (%)")
    ax_cm.set_xticks(range(n_cls))
    ax_cm.set_yticks(range(n_cls))
    ax_cm.set_xticklabels(codes[:n_cls], fontsize=10, fontweight="bold")
    ax_cm.set_yticklabels(codes[:n_cls], fontsize=10, fontweight="bold")
    ax_cm.set_xlabel("AI Dự Đoán (Predicted Class)", fontsize=11, fontweight="bold")
    ax_cm.set_ylabel("Thực Tế Bác Sĩ (True Ground Truth)", fontsize=11, fontweight="bold")
    ax_cm.set_title("Ma Trận Nhầm Lẫn Chuẩn Hóa (%)", fontsize=12, fontweight="bold")

    for i in range(n_cls):
        for j in range(n_cls):
            val = cm_norm[i, j]
            count = cm[i, j]
            text_color = "white" if val > 50 else "black"
            ax_cm.text(
                j,
                i,
                f"{val:.1f}%\n({count})",
                ha="center",
                va="center",
                color=text_color,
                fontsize=8,
            )

    plt.tight_layout()

    saved_path: Optional[Path] = None
    if output_dir is not None:
        out_p = Path(output_dir)
        out_p.mkdir(parents=True, exist_ok=True)
        saved_path = out_p / "confusion_matrix_5x5.png"
        fig_cm.savefig(saved_path, dpi=300, bbox_inches="tight")
        if legacy_dir is not None:
            leg_p = Path(legacy_dir)
            leg_p.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved_path, leg_p / "confusion_matrix_5x5.png")
        print(f"[OK] Đã lưu biểu đồ ma trận nhầm lẫn 300 DPI: {saved_path.resolve()}")

    if show_plots:
        plt.show()
    else:
        plt.close(fig_cm)

    return fig_cm, saved_path


def render_ablation_bar_chart(
    all_methods_metrics: Dict[str, Dict[str, Any]],
    method_keys: List[str],
    output_dir: Optional[Union[str, Path]] = None,
    legacy_dir: Optional[Union[str, Path]] = None,
    show_plots: bool = True,
) -> Tuple[plt.Figure, Optional[Path]]:
    """Renders a 300-DPI grouped bar chart comparing WSSS methods across mIoU, mDice, LYM IoU, and NEC IoU."""
    active_keys = [k for k in method_keys if k in all_methods_metrics]
    if not active_keys:
        active_keys = list(all_methods_metrics.keys())
    short_labels = [
        (k.split("_")[0] if k.startswith("M") and "_" in k else f"M{i}")
        for i, k in enumerate(active_keys, 1)
    ]
    miou_vals = [all_methods_metrics[k]["mIoU_4cls"] for k in active_keys]
    mdice_vals = [all_methods_metrics[k]["mDice_4cls"] for k in active_keys]
    lym_vals = [all_methods_metrics[k]["per_class_iou"]["LYM"] for k in active_keys]
    nec_vals = [all_methods_metrics[k]["per_class_iou"]["NEC"] for k in active_keys]

    x = np.arange(len(active_keys))
    width = 0.20

    fig_bar, ax_bar = plt.subplots(figsize=(10.5 if len(active_keys) <= 5 else 12.5, 5.5), dpi=300)
    b1 = ax_bar.bar(x - 1.5 * width, miou_vals, width, label="mIoU 4 Lớp (%)", color="#1f77b4")
    b2 = ax_bar.bar(x - 0.5 * width, mdice_vals, width, label="mDice 4 Lớp (%)", color="#2ca02c")
    b3 = ax_bar.bar(x + 0.5 * width, lym_vals, width, label="LYM IoU (%)", color="#ff7f0e")
    b4 = ax_bar.bar(x + 1.5 * width, nec_vals, width, label="NEC IoU (%)", color="#d62728")

    ax_bar.set_ylabel("Chỉ Số Đánh Giá (%)", fontsize=11, fontweight="bold")
    ax_bar.set_title(
        f"Đối Sánh Thực Nghiệm {len(active_keys)} Phương Pháp WSSS Trên TCGA-BRCA (Ablation Study)",
        fontsize=12,
        fontweight="bold",
    )
    ax_bar.set_xticks(x)
    ax_bar.set_xticklabels(short_labels, fontsize=10, fontweight="bold")
    all_vals = miou_vals + mdice_vals + lym_vals + nec_vals
    y_min = max(0.0, min(all_vals) - 10.0) if all_vals else 0.0
    ax_bar.set_ylim(y_min, 100.0)
    ax_bar.grid(axis="y", linestyle="--", alpha=0.5)
    ax_bar.legend(loc="upper left", ncol=4, fontsize=9)

    for bars in (b1, b2, b3, b4):
        for bar in bars:
            h = bar.get_height()
            ax_bar.annotate(
                f"{h:.1f}",
                xy=(bar.get_x() + bar.get_width() / 2, h),
                xytext=(0, 2),
                textcoords="offset points",
                ha="center",
                va="bottom",
                fontsize=7.5,
            )

    plt.tight_layout()

    saved_path: Optional[Path] = None
    if output_dir is not None:
        out_p = Path(output_dir)
        out_p.mkdir(parents=True, exist_ok=True)
        saved_path = out_p / "ablation_methods_comparison.png"
        fig_bar.savefig(saved_path, dpi=300, bbox_inches="tight")
        if legacy_dir is not None:
            leg_p = Path(legacy_dir)
            leg_p.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved_path, leg_p / "ablation_methods_comparison.png")
        print(f"[OK] Đã lưu biểu đồ đối sánh Ablation 300 DPI: {saved_path.resolve()}")

    if show_plots:
        plt.show()
    else:
        plt.close(fig_bar)

    return fig_bar, saved_path


def package_and_download_results(
    output_dir: Union[str, Path],
    zip_file_path: Optional[Union[str, Path]] = None,
    drive_export_dir: Optional[Union[str, Path]] = None,
    trigger_browser_download: bool = True,
) -> Path:
    """Packages all files in output_dir into a ZIP archive and optionally triggers Colab download."""
    out_p = Path(output_dir).resolve()
    run_folder_name = out_p.name

    if zip_file_path is None:
        zip_p = out_p.parent / f"{run_folder_name}.zip"
    else:
        zip_p = Path(zip_file_path).resolve()

    zip_p.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_p, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for file_item in sorted(out_p.rglob("*")):
            if file_item.is_file():
                arcname = f"{run_folder_name}/{file_item.relative_to(out_p).as_posix()}"
                zf.write(file_item, arcname=arcname)

    print(f"[OK] Đã đóng gói thành công vào: {zip_p}")

    # Optional automatic backup to Google Drive if mounted or specified
    if drive_export_dir is not None:
        drive_out = Path(drive_export_dir)
        try:
            drive_out.mkdir(parents=True, exist_ok=True)
            drive_zip = drive_out / zip_p.name
            shutil.copy2(zip_p, drive_zip)
            print(f"[OK] Đã sao lưu bản nén kết quả lên Google Drive: {drive_zip}")
        except Exception as exc_drive:
            print(f"[THÔNG BÁO] Không thể sao lưu lên Google Drive ({exc_drive}).")

    if trigger_browser_download:
        print(f"--> Đang kích hoạt trình duyệt tự động tải về tệp: {zip_p.name}...")
        try:
            from google.colab import files  # type: ignore

            files.download(str(zip_p))
            print("[OK] Yêu cầu tải tệp đã được gửi thành công tới trình duyệt!")
        except Exception as exc:
            print(
                f"[THÔNG BÁO]: Nếu chạy ngoài Google Colab hoặc trình duyệt chặn pop-up, "
                f"tệp kết quả đã được lưu sẵn tại: {zip_p} (Chi tiết: {exc})"
            )

    return zip_p
